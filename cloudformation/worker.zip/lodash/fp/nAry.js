module.exports = require('./ary');
