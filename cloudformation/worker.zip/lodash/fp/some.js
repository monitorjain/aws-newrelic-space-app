var convert = require('./convert'),
    func = convert('some', require('../some'));

func.placeholder = require('./placeholder');
module.exports = func;
