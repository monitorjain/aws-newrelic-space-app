module.exports = require('./xor');
